# Conformance tests

These conformance tests are developed in https://github.com/googleapis/conformance-tests/
and then copied here when prompted that new tests are available.

### Generating test.pb.go

```
protoc --go_out=. *.proto
```
